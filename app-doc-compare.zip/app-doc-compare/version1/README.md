# App Doc Compare

Aplicacion web simple para la fase 1 de comparacion documental.

## Incluye

- carga de PDF digital
- carga de DOCX
- comparacion basica de texto
- resumen de diferencias
- uso de documentos sintenticos de ejemplo

## Requisitos

- Python con `pypdf` y `python-docx` disponibles en el runtime de Codex

## Ejecucion

```bash
python app.py
```

Luego abrir:

```text
http://127.0.0.1:8000
```

## Archivos de prueba

- `poliza_v1.pdf`
- `poliza_v2.pdf`

