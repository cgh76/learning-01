Prompt base para crear la aplicación:

Quiero que construyas una aplicacion web simple para la fase 1 de una PoC de comparacion documental.

Objetivo:
- Recibir dos documentos como entrada.
- Soportar archivos PDF digital y Word DOCX.
- Extraer texto de ambos archivos.
- Comparar el contenido y mostrar diferencias claras para un analista.
- Generar un resumen simple del resultado.

Alcance de esta primera fase:
- Incluir solo documentos digitales.
- No incluir PDF escaneado.
- No incluir OCR.
- No incluir persistencia ni base de datos.
- No incluir autenticacion ni roles.

Requisitos funcionales:
- Interfaz web simple y clara.
- Carga de dos archivos.
- Boton para usar documentos sintéticos de ejemplo.
- Mostrar:
  - total de diferencias
  - agregados
  - eliminados
  - modificados
  - cambios numericos
  - cambios textuales sin impacto material evidente
- Mostrar texto anterior y texto nuevo por cada diferencia.
- Incluir un resumen ejecutivo breve.

Requisitos tecnicos:
- Mantener la arquitectura simple y modular.
- Separar logica de:
  - ingestion
  - extraccion
  - normalizacion
  - comparacion
  - presentacion
- Usar una solucion ligera y facil de ejecutar localmente.
- Preferir un unico backend sencillo con una interfaz web minima.

Criterios de aceptacion:
- La aplicacion debe poder comparar dos PDFs sintenticos de prueba.
- La aplicacion debe poder comparar dos DOCX digitales.
- La aplicacion debe ejecutar localmente sin dependencias pesadas.
- El resultado debe ser entendible y util para la PoC.

Estilo de implementacion:
- Codigo limpio.
- Comentarios breves solo donde aporten claridad.
- Interfaz visual sobria, profesional y facil de usar.
- Pensar la solucion como una base para evolucionar luego a OCR y persistencia.

Si hay que tomar decisiones de arquitectura, prioriza simplicidad, claridad y extensibilidad.