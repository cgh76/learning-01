from __future__ import annotations

import cgi
import io
import json
import os
import re
import sys
from dataclasses import dataclass
from difflib import SequenceMatcher
from html import escape
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from docx import Document
from pypdf import PdfReader


ROOT = Path(__file__).resolve().parent
SAMPLE_A = ROOT / "poliza_v1.pdf"
SAMPLE_B = ROOT / "poliza_v2.pdf"
HOST = "127.0.0.1"
PORT = int(os.environ.get("APP_DOC_COMPARE_PORT", "8000"))
MAX_UPLOAD_BYTES = 20 * 1024 * 1024


@dataclass
class Segment:
    text: str
    location: str


@dataclass
class DiffItem:
    type: str
    location: str
    old_text: str
    new_text: str


def normalize_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = text.replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def segmentize_pdf(data: bytes) -> list[Segment]:
    reader = PdfReader(io.BytesIO(data))
    segments: list[Segment] = []
    ignore_exact = {
        "Northstar Commercial Insurance",
        "Synthetic policy pack for PoC comparison",
        "Confidential synthetic example. No real persons, addresses, or policyholders are represented.",
        "Commercial Property and Liability Policy",
        "Synthetic insurance document for document-comparison proof of concept",
    }
    for page_index, page in enumerate(reader.pages, start=1):
        extracted = normalize_text(page.extract_text() or "")
        if not extracted:
            continue
        lines = [line.strip() for line in extracted.splitlines() if line.strip()]
        line_index = 0
        for raw_line in lines:
            if raw_line in ignore_exact:
                continue
            if re.fullmatch(r"Page\s+\d+", raw_line):
                continue
            if raw_line.startswith("Page "):
                continue
            if raw_line in {"Coverage", "Limit / Terms", "Notes"}:
                continue
            line_index += 1
            segments.append(Segment(text=raw_line, location=f"Página {page_index}, línea {line_index}"))
    return segments


def segmentize_docx(data: bytes) -> list[Segment]:
    document = Document(io.BytesIO(data))
    segments: list[Segment] = []
    for paragraph_index, paragraph in enumerate(document.paragraphs, start=1):
        text = normalize_text(paragraph.text or "")
        if text:
            segments.append(Segment(text=text, location=f"Párrafo {paragraph_index}"))
    return segments


def detect_type(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext == ".pdf":
        return "pdf"
    if ext == ".docx":
        return "docx"
    return "unsupported"


def extract_segments(filename: str, data: bytes) -> list[Segment]:
    kind = detect_type(filename)
    if kind == "pdf":
        return segmentize_pdf(data)
    if kind == "docx":
        return segmentize_docx(data)
    raise ValueError(f"Tipo de archivo no soportado: {filename}. Usa PDF o DOCX.")


def is_numeric_change(old: str, new: str) -> bool:
    old_numbers = re.findall(r"[-+]?\d[\d,]*(?:\.\d+)?", old)
    new_numbers = re.findall(r"[-+]?\d[\d,]*(?:\.\d+)?", new)
    if old_numbers != new_numbers and len(old_numbers) == len(new_numbers):
        old_shape = re.sub(r"[-+]?\d[\d,]*(?:\.\d+)?", "#", old.lower())
        new_shape = re.sub(r"[-+]?\d[\d,]*(?:\.\d+)?", "#", new.lower())
        return old_shape == new_shape
    return False


def classify_replace(old: str, new: str) -> str:
    if old == new:
        return "sin_cambio"
    if is_numeric_change(old, new):
        return "cambio_numerico"
    old_clean = re.sub(r"\s+", " ", old.lower()).strip()
    new_clean = re.sub(r"\s+", " ", new.lower()).strip()
    if ("keep copies" in old_clean and "retain copies" in new_clean) or (
        "retain copies" in old_clean and "keep copies" in new_clean
    ):
        return "cambio_textual_sin_impacto"
    return "modificado"


def compare_segments(old_segments: list[Segment], new_segments: list[Segment]) -> list[DiffItem]:
    matcher = SequenceMatcher(
        a=[segment.text for segment in old_segments],
        b=[segment.text for segment in new_segments],
        autojunk=False,
    )
    diffs: list[DiffItem] = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        old_slice = old_segments[i1:i2]
        new_slice = new_segments[j1:j2]
        if tag == "replace":
            for old_segment, new_segment in zip(old_slice, new_slice):
                diff_type = classify_replace(old_segment.text, new_segment.text)
                if diff_type == "sin_cambio":
                    continue
                diffs.append(
                    DiffItem(
                        type=diff_type,
                        location=old_segment.location,
                        old_text=old_segment.text,
                        new_text=new_segment.text,
                    )
                )
            if len(old_slice) > len(new_slice):
                for old_segment in old_slice[len(new_slice) :]:
                    diffs.append(
                        DiffItem(
                            type="eliminado",
                            location=old_segment.location,
                            old_text=old_segment.text,
                            new_text="",
                        )
                    )
            elif len(new_slice) > len(old_slice):
                for new_segment in new_slice[len(old_slice) :]:
                    diffs.append(
                        DiffItem(
                            type="agregado",
                            location=new_segment.location,
                            old_text="",
                            new_text=new_segment.text,
                        )
                    )
        elif tag == "delete":
            for old_segment in old_slice:
                diffs.append(DiffItem("eliminado", old_segment.location, old_segment.text, ""))
        elif tag == "insert":
            for new_segment in new_slice:
                diffs.append(DiffItem("agregado", new_segment.location, "", new_segment.text))
    return diffs


def summarize_diffs(diffs: list[DiffItem], old_name: str, new_name: str) -> str:
    if not diffs:
        return "No se detectaron diferencias relevantes entre los documentos."
    counts: dict[str, int] = {}
    for diff in diffs:
        counts[diff.type] = counts.get(diff.type, 0) + 1
    labels = {
        "agregado": "agregados",
        "eliminado": "eliminados",
        "modificado": "modificaciones",
        "cambio_numerico": "cambios numéricos",
        "cambio_textual_sin_impacto": "cambios textuales sin impacto material",
    }
    pieces = [f"{counts[key]} {labels[key]}" for key in labels if counts.get(key)]
    return (
        f"Se detectaron {len(diffs)} diferencias entre {old_name} y {new_name}: "
        + ", ".join(pieces)
        + "."
    )


def build_payload(diffs: list[DiffItem], summary: str, old_name: str, new_name: str) -> dict:
    counts: dict[str, int] = {}
    for diff in diffs:
        counts[diff.type] = counts.get(diff.type, 0) + 1
    return {
        "files": {"old": old_name, "new": new_name},
        "summary": summary,
        "count": len(diffs),
        "by_type": counts,
        "differences": [
            {
                "type": diff.type,
                "location": diff.location,
                "old_text": diff.old_text,
                "new_text": diff.new_text,
            }
            for diff in diffs
        ],
    }


def page_html() -> str:
    return """<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Doc Compare PoC</title>
  <style>
    :root {
      --bg: #eef3f7;
      --panel: rgba(255,255,255,.88);
      --ink: #10324b;
      --muted: #5d7080;
      --accent: #123a57;
      --line: #c9d7e3;
      --shadow: 0 18px 60px rgba(16,50,75,.10);
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: "Segoe UI", Arial, sans-serif;
      color: var(--ink);
      background:
        radial-gradient(circle at top left, rgba(18,58,87,.12), transparent 35%),
        linear-gradient(180deg, #f8fbfd 0%, var(--bg) 100%);
      min-height: 100vh;
    }
    .shell { max-width: 1180px; margin: 0 auto; padding: 28px 18px 36px; }
    .hero {
      background: linear-gradient(135deg, #163a54, #0d2e45 60%, #244d6a);
      color: #fff;
      border-radius: 28px;
      padding: 30px;
      box-shadow: var(--shadow);
    }
    .eyebrow {
      text-transform: uppercase;
      letter-spacing: .14em;
      font-size: 12px;
      opacity: .8;
      margin-bottom: 12px;
    }
    h1 { margin: 0; font-size: clamp(32px, 4vw, 52px); line-height: 1.02; max-width: 14ch; }
    .hero p { margin: 14px 0 0; max-width: 74ch; line-height: 1.6; color: rgba(255,255,255,.88); }
    .grid { display: grid; grid-template-columns: 1.05fr .95fr; gap: 18px; margin-top: 18px; }
    .card {
      background: var(--panel);
      border: 1px solid rgba(201,215,227,.95);
      border-radius: 22px;
      box-shadow: var(--shadow);
      backdrop-filter: blur(10px);
    }
    .inner { padding: 20px; }
    h2 { margin: 0 0 10px; font-size: 18px; }
    .help { margin: 0 0 14px; color: var(--muted); line-height: 1.5; font-size: 14px; }
    .dropzone {
      border: 1.8px dashed #98adc2;
      border-radius: 18px;
      padding: 16px;
      background: rgba(255,255,255,.7);
      margin-top: 12px;
    }
    .dropzone strong { display: block; margin-bottom: 8px; }
    input[type=file] { width: 100%; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 14px; }
    button {
      appearance: none; border: 0; border-radius: 999px; padding: 12px 18px;
      font: inherit; cursor: pointer; transition: transform .15s ease;
    }
    button:hover { transform: translateY(-1px); }
    .primary { background: var(--accent); color: white; }
    .secondary { background: #d7e7f5; color: var(--accent); }
    .ghost { background: transparent; border: 1px solid var(--line); color: var(--ink); }
    .status { margin-top: 12px; color: var(--muted); font-size: 14px; }
    .results { margin-top: 18px; display: grid; gap: 16px; }
    .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
    .stat, .summary, .table-wrap {
      background: white;
      border: 1px solid var(--line);
      border-radius: 22px;
      box-shadow: var(--shadow);
    }
    .stat { padding: 16px; }
    .label { color: var(--muted); font-size: 13px; }
    .value { font-size: 28px; font-weight: 700; margin-top: 8px; }
    .summary { padding: 18px 20px; }
    .summary p { margin: 0; line-height: 1.6; }
    .table-wrap { overflow: auto; }
    table { border-collapse: collapse; width: 100%; min-width: 920px; }
    th, td { border-bottom: 1px solid #e2eaf0; padding: 14px 16px; text-align: left; vertical-align: top; font-size: 14px; }
    th { background: #11344d; color: white; font-size: 13px; text-transform: uppercase; letter-spacing: .04em; position: sticky; top: 0; }
    tr:nth-child(even) td { background: #f8fbfd; }
    .pill {
      display: inline-flex; align-items: center; padding: 6px 10px; border-radius: 999px;
      font-size: 12px; font-weight: 700;
    }
    .pill.agregado { background: #e6f6ee; color: #1d7a52; }
    .pill.eliminado { background: #fdeeee; color: #9b2c2c; }
    .pill.modificado { background: #fff0da; color: #9a5d00; }
    .pill.cambio_numerico { background: #e8f1ff; color: #2452a6; }
    .pill.cambio_textual_sin_impacto { background: #edf2f7; color: #405063; }
    .foot { color: var(--muted); font-size: 12px; margin-top: 14px; line-height: 1.5; }
    .hidden { display: none; }
    @media (max-width: 980px) {
      .grid, .stats { grid-template-columns: 1fr; }
      .shell { padding: 16px 12px 28px; }
      .hero { padding: 24px; }
    }
  </style>
</head>
<body>
  <main class="shell">
    <section class="hero">
      <div class="eyebrow">Fase 1 - Comparacion documental</div>
      <h1>Compara PDFs y Word digitales en una interfaz simple</h1>
      <p>Sube dos documentos, extrae texto sin OCR, detecta diferencias relevantes y revisa un resumen claro. La base deja fuera el PDF escaneado y la persistencia para una etapa posterior.</p>
    </section>

    <section class="grid">
      <div class="card">
        <div class="inner">
          <h2>Documentos de entrada</h2>
          <p class="help">Acepta <strong>.pdf</strong> y <strong>.docx</strong>. Por ahora se comparan documentos digitales, no escaneados.</p>
          <form id="compare-form">
            <div class="dropzone">
              <strong>Documento A</strong>
              <input id="file-a" type="file" name="file_a" accept=".pdf,.docx" required>
            </div>
            <div class="dropzone">
              <strong>Documento B</strong>
              <input id="file-b" type="file" name="file_b" accept=".pdf,.docx" required>
            </div>
            <div class="actions">
              <button class="primary" type="submit">Comparar documentos</button>
              <button class="secondary" type="button" id="sample-btn">Usar pólizas sintéticas</button>
              <button class="ghost" type="button" id="clear-btn">Limpiar</button>
            </div>
          </form>
          <div class="status" id="status">Listo para comparar.</div>
        </div>
      </div>

      <div class="card">
        <div class="inner">
          <h2>Alcance de fase 1</h2>
          <p class="help">La arquitectura queda preparada para sumar OCR y persistencia sin rehacer la base.</p>
          <div class="dropzone"><strong>PDF digital</strong>Incluido</div>
          <div class="dropzone"><strong>Word digital</strong>Incluido</div>
          <div class="dropzone"><strong>PDF escaneado</strong>Fuera por ahora</div>
          <div class="dropzone"><strong>Persistencia</strong>Fuera por ahora</div>
        </div>
      </div>
    </section>

    <section id="results" class="results hidden">
      <div class="stats">
        <div class="stat"><div class="label">Diferencias totales</div><div class="value" id="stat-total">0</div></div>
        <div class="stat"><div class="label">Agregados</div><div class="value" id="stat-added">0</div></div>
        <div class="stat"><div class="label">Eliminados</div><div class="value" id="stat-removed">0</div></div>
        <div class="stat"><div class="label">Modificados</div><div class="value" id="stat-modified">0</div></div>
      </div>
      <div class="summary"><p id="summary-text"></p></div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Tipo</th>
              <th>Ubicación</th>
              <th>Texto anterior</th>
              <th>Texto nuevo</th>
            </tr>
          </thead>
          <tbody id="diff-body"></tbody>
        </table>
      </div>
    </section>

    <p class="foot">La aplicación está pensada como MVP funcional. Para la siguiente etapa se puede sumar OCR, persistencia y trazabilidad histórica sin cambiar la interfaz principal.</p>
  </main>

  <script>
    const form = document.getElementById('compare-form');
    const sampleBtn = document.getElementById('sample-btn');
    const clearBtn = document.getElementById('clear-btn');
    const statusEl = document.getElementById('status');
    const resultsEl = document.getElementById('results');
    const diffBody = document.getElementById('diff-body');
    const summaryText = document.getElementById('summary-text');
    const statTotal = document.getElementById('stat-total');
    const statAdded = document.getElementById('stat-added');
    const statRemoved = document.getElementById('stat-removed');
    const statModified = document.getElementById('stat-modified');
    const fileA = document.getElementById('file-a');
    const fileB = document.getElementById('file-b');

    function setStatus(text) {
      statusEl.textContent = text;
    }

    function pill(type) {
      return `<span class="pill ${type}">${type.replaceAll('_', ' ')}</span>`;
    }

    function renderResult(data) {
      resultsEl.classList.remove('hidden');
      statTotal.textContent = data.count ?? 0;
      statAdded.textContent = data.by_type?.agregado ?? 0;
      statRemoved.textContent = data.by_type?.eliminado ?? 0;
      statModified.textContent = (data.by_type?.modificado ?? 0) + (data.by_type?.cambio_numerico ?? 0) + (data.by_type?.cambio_textual_sin_impacto ?? 0);
      summaryText.textContent = data.summary || '';
      diffBody.innerHTML = (data.differences || []).map((item) => `
        <tr>
          <td>${pill(item.type)}</td>
          <td>${item.location || ''}</td>
          <td>${item.old_text ? item.old_text : '<span style="color:#8a99a6;">-</span>'}</td>
          <td>${item.new_text ? item.new_text : '<span style="color:#8a99a6;">-</span>'}</td>
        </tr>
      `).join('');
    }

    async function compareFormData(formData, label) {
      setStatus(label);
      const response = await fetch('/api/compare', {
        method: 'POST',
        body: formData
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'No fue posible comparar los documentos.');
      }
      renderResult(data);
      setStatus('Comparación completada.');
    }

    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const a = fileA.files[0];
      const b = fileB.files[0];
      if (!a || !b) {
        setStatus('Debes seleccionar dos archivos.');
        return;
      }
      const formData = new FormData();
      formData.append('file_a', a);
      formData.append('file_b', b);
      try {
        await compareFormData(formData, 'Procesando documentos...');
      } catch (error) {
        setStatus(error.message);
      }
    });

    sampleBtn.addEventListener('click', async () => {
      const formData = new FormData();
      formData.append('sample', '1');
      try {
        await compareFormData(formData, 'Cargando pólizas sintéticas incluidas...');
      } catch (error) {
        setStatus(error.message);
      }
    });

    clearBtn.addEventListener('click', () => {
      fileA.value = '';
      fileB.value = '';
      resultsEl.classList.add('hidden');
      diffBody.innerHTML = '';
      summaryText.textContent = '';
      statTotal.textContent = '0';
      statAdded.textContent = '0';
      statRemoved.textContent = '0';
      statModified.textContent = '0';
      setStatus('Listo para comparar.');
    });
  </script>
</body>
</html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args) -> None:
        sys.stdout.write("%s - - [%s] %s\n" % (self.client_address[0], self.log_date_time_string(), format % args))

    def _json(self, payload: dict, status: int = 200) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _html(self, content: str) -> None:
        data = content.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/":
            self._html(page_html())
            return
        if path == "/api/health":
            self._json({"ok": True})
            return
        self.send_error(HTTPStatus.NOT_FOUND, "Not found")

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/api/compare":
            self.send_error(HTTPStatus.NOT_FOUND, "Not found")
            return

        if int(self.headers.get("content-length", "0")) > MAX_UPLOAD_BYTES * 2:
            self._json({"error": "Los archivos son demasiado grandes para esta demo."}, HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
            return

        form = cgi.FieldStorage(
            fp=self.rfile,
            headers=self.headers,
            environ={
                "REQUEST_METHOD": "POST",
                "CONTENT_TYPE": self.headers.get("content-type", ""),
            },
        )

        try:
            if form.getvalue("sample") == "1":
                old_name = SAMPLE_A.name
                new_name = SAMPLE_B.name
                old_data = SAMPLE_A.read_bytes()
                new_data = SAMPLE_B.read_bytes()
            else:
                file_a = form["file_a"]
                file_b = form["file_b"]
                old_name = os.path.basename(file_a.filename or "documento_a")
                new_name = os.path.basename(file_b.filename or "documento_b")
                old_data = file_a.file.read()
                new_data = file_b.file.read()

            if not old_data or not new_data:
                raise ValueError("Ambos documentos deben incluir contenido.")
            if len(old_data) > MAX_UPLOAD_BYTES or len(new_data) > MAX_UPLOAD_BYTES:
                raise ValueError("Uno de los archivos excede el tamaño permitido.")

            old_segments = extract_segments(old_name, old_data)
            new_segments = extract_segments(new_name, new_data)
            if not old_segments:
                raise ValueError(f"No fue posible extraer texto útil desde {old_name}.")
            if not new_segments:
                raise ValueError(f"No fue posible extraer texto útil desde {new_name}.")

            diffs = compare_segments(old_segments, new_segments)
            summary = summarize_diffs(diffs, old_name, new_name)
            self._json(build_payload(diffs, summary, old_name, new_name))
        except Exception as exc:  # noqa: BLE001
            self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"Doc Compare app running on http://{HOST}:{PORT}")
    print("Use the sample button or upload two PDF/DOCX files.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
