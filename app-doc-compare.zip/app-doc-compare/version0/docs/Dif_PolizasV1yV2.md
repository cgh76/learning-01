
# Diferencias esperadas entre poliza_v1.pdf y poliza_v2.pdf

Este archivo documenta las diferencias sinteticas conocidas de antemano para validar la PoC de comparacion.

| ID | Tipo | Ubicacion aproximada | Diferencia esperada | Materialidad |
| --- | --- | --- | --- | --- |
| D01 | Modificacion numerica | Portada y Declaraciones | Numero de poliza cambia de NCI-CC-2608-1042 a NCI-CC-2608-1087 | Material |
| D02 | Modificacion nominal | Portada y Declaraciones | Titular cambia de Northstar Retail Group a Northstar Logistics Group | Material |
| D03 | Modificacion de fechas | Portada y Declaraciones | Inicio y vencimiento cambian de 01-Aug-2026 / 31-Jul-2027 a 15-Aug-2026 / 14-Aug-2027 | Material |
| D04 | Modificacion numerica | Portada y Declaraciones | Prima anual cambia de $18,400 a $19,250 | Material |
| D05 | Modificacion numerica | Key deductibles and limits | Deducible de propiedad cambia de $5,000 a $7,500 | Material |
| D06 | Modificacion numerica | Key deductibles and limits | Limite de responsabilidad cambia de $2,000,000 / $4,000,000 a $2,500,000 / $5,000,000 | Material |
| D07 | Agregado | Key deductibles and limits | Cobertura cyber response aparece con limite de $100,000 en v2 | Material |
| D08 | Eliminacion | Endorsements | Roadside assistance for company vehicles se elimina en v2 | Material |
| D09 | Modificacion textual sin cambio de negocio | Claims and notices | 'keep copies' cambia a 'retain copies' con el mismo sentido operativo | No material |
| D10 | Modificacion numerica | Coverage snapshot | Waiting period del ingreso cambia de 72 hours a 48 hours | Material |
