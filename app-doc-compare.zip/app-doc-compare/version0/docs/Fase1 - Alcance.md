
# Fase 1 - Alcance inicial

## Objetivo

Construir una primera version de la comparacion documental enfocada en documentos digitales, con entrada por:

- PDF digital
- Word (`.docx`)

La salida debe entregar las diferencias detectadas y un resumen util para analistas.

## Lo que entra en esta fase

### Entrada

- Carga de un archivo PDF digital.
- Carga de un archivo Word.
- Validacion basica del tipo de archivo.
- Extraccion de texto y estructura util para comparar.

### Procesamiento

- Normalizacion de texto.
- Comparacion entre dos documentos.
- Clasificacion basica de diferencias:
  - agregado
  - eliminado
  - modificado
  - cambio numerico
  - cambio textual sin impacto material evidente

### Salida

- Resultado de la comparacion en pantalla o reporte.
- Conteo total de diferencias.
- Resumen generado a partir del diff.
- Evidencia de texto anterior y nuevo por cada cambio.

## Lo que queda fuera por ahora

- PDF escaneado.
- OCR.
- Persistencia historica.
- Versionado de comparaciones.
- Integracion con almacenamiento externo.
- Firma digital, forms o validacion juridica avanzada.

## Criterio de exito

La fase 1 se considera bien resuelta si el sistema puede:

- recibir dos documentos digitales,
- extraer su contenido,
- detectar diferencias relevantes,
- y devolver un resultado consistente y explicable.

## Recomendacion tecnica

Mantener una arquitectura modular desde el inicio:

- `ingestion` para leer archivos
- `extraction` para obtener texto
- `normalization` para limpiar contenido
- `comparison` para calcular diferencias
- `reporting` para mostrar resultados

Eso permite sumar OCR y persistencia despues sin reescribir la base.

## Siguiente paso sugerido

Definir el formato exacto del primer entregable:

1. prototipo de consola,
2. aplicacion web simple,
3. o API con interfaz minima.


