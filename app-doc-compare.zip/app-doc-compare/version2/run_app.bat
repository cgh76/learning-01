@echo off
setlocal

cd /d "%~dp0"
C:\Python313\python app.py

endlocal
