# App Doc Compare

Aplicacion web simple para la fase 1 de comparacion documental.

## Incluye

- carga de PDF digital
- carga de DOCX
- comparacion basica de texto
- resumen de diferencias
- uso de documentos sintenticos de ejemplo

## Requisitos

- Python con `pypdf` y `python-docx` disponibles en el runtime de Codex
- `OPENAI_API_KEY` para activar la comparación asistida por IA
- opcionalmente `OPENAI_MODEL` para cambiar el modelo usado por la API

## Ejecucion

```bash
python app.py
```

Luego abrir:

```text
http://127.0.0.1:8000
```

## Archivos de prueba

- `poliza_v1.pdf`
- `poliza_v2.pdf`

## Modo IA

Si `OPENAI_API_KEY` está definida, la app usa la Responses API de OpenAI para consolidar y clasificar diferencias con ayuda del modelo.
Si la variable no está presente, la app sigue funcionando con comparación local como respaldo.
